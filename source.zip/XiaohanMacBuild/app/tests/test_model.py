import json
from pathlib import Path
import tempfile
import unittest
from model import PetState, STAGES, TOILET_REMIND_SECONDS, TOILET_URGENT_SECONDS, TOILET_FULL_SECONDS

class CareTests(unittest.TestCase):
    def test_toilet_time_boundaries_and_completion(self):
        state=PetState()
        self.assertTrue(state.check('toilet',100))
        state.toilet_seconds=TOILET_REMIND_SECONDS-1
        self.assertNotIn('toilet',state.low_needs())
        state.tick(1,False)
        self.assertIn('toilet',state.low_needs())
        self.assertNotIn('toilet',state.urgent_needs())
        self.assertEqual(state.check('ball',100),'')
        state.toilet_seconds=TOILET_URGENT_SECONDS
        self.assertIn('toilet',state.urgent_needs())
        for action in ('walk','ball','toy'):self.assertTrue(state.check(action,100))
        for action in ('feed','water','sleep','toilet'):self.assertEqual(state.check(action,100),'')
        self.assertEqual(state.finish('toilet',100),'')
        self.assertEqual(state.toilet_seconds,0)
        self.assertFalse(state.low_needs())
        self.assertTrue(state.finish('toilet',101))
        self.assertEqual(state.completed,1)
        state.toilet_seconds=TOILET_FULL_SECONDS;state.tick(10,True)
        self.assertEqual(state.toilet_seconds,TOILET_FULL_SECONDS)

    def test_toilet_old_save_defaults_and_no_offline_accumulation(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'pet.json';state=PetState();state.toilet_seconds=5000;state.save(path)
            self.assertEqual(PetState.load(path).toilet_seconds,5000)
            data=json.loads(path.read_text(encoding='utf-8'));del data['toilet_seconds']
            path.write_text(json.dumps(data),encoding='utf-8')
            self.assertEqual(PetState.load(path).toilet_seconds,0)
            data['toilet_seconds']=-1;path.write_text(json.dumps(data),encoding='utf-8')
            with self.assertRaises(ValueError):PetState.load(path)

    def test_low_needs_prioritize_lowest_and_critical_guards(self):
        state=PetState()
        for key in ('food','water','energy'):state.values[key]=25
        self.assertEqual(state.low_needs(),())
        state.values.update(food=24,water=12,energy=20)
        self.assertEqual(state.low_needs(),('water','energy','food'))
        self.assertEqual(state.check('ball',100),'')
        state.values['food']=11
        self.assertEqual(state.low_needs()[0],'food')
        for action in ('walk','ball','toy'):self.assertTrue(state.check(action,100))
        for action in ('feed','water','sleep'):self.assertEqual(state.check(action,100),'')

    def test_care_recovers_only_matching_need(self):
        state=PetState();state.values.update(food=5,water=6,energy=7)
        state.finish('feed',100)
        self.assertEqual(state.low_needs(),('water','energy'))
        state.finish('water',100)
        self.assertEqual(state.low_needs(),('energy',))
        state.finish('sleep',100)
        self.assertEqual(state.low_needs(),())
        self.assertEqual(state.need_text(),'')

    def test_fetch_can_repeat_immediately_even_with_old_cooldown(self):
        state=PetState();state.cooldowns['ball']=1000
        self.assertEqual(state.check('ball',100),'')
        self.assertEqual(state.finish('ball',100),'')
        self.assertEqual(state.check('ball',100),'')
        self.assertEqual(state.finish('ball',101),'')
        self.assertEqual(state.completed,2)

    def test_completion_and_cooldown(self):
        state=PetState();before=state.values.copy()
        self.assertEqual(state.check('feed',100),'')
        self.assertEqual(state.values,before)
        self.assertEqual(state.finish('feed',100),'')
        self.assertEqual(state.values['food'],90)
        self.assertTrue(state.finish('feed',101))
        self.assertEqual(state.completed,1)

    def test_saturation_and_energy_guards(self):
        state=PetState();state.values['food']=98
        self.assertTrue(state.check('feed',100))
        state.values['energy']=5
        for action in ('walk','ball','toy'):
            self.assertTrue(state.check(action,100))
        self.assertEqual(state.finish('sleep',100),'')
        self.assertEqual(state.values['energy'],30)

    def test_growth_requires_both_conditions_and_never_reverses(self):
        state=PetState();state.companion_seconds=STAGES[2][0]
        state.promote();self.assertEqual(state.unlocked_stage,0)
        state.values['bond']=21;state.promote();self.assertEqual(state.unlocked_stage,1)
        state.values['bond']=55;state.promote();self.assertEqual(state.unlocked_stage,2)
        state.values['bond']=0;state.promote();self.assertEqual(state.unlocked_stage,2)
        self.assertEqual(state.stage,0)

    def test_growth_time_boundaries_and_manual_choice(self):
        state=PetState();state.values['bond']=100
        for stage,hours in ((1,20),(2,40)):
            state.companion_seconds=hours*3600-1;state.promote()
            self.assertEqual(state.unlocked_stage,stage-1)
            self.assertTrue(state.select_stage(stage))
            state.tick(1,True)
            self.assertEqual(state.unlocked_stage,stage)
            self.assertEqual(state.select_stage(stage),'')
            self.assertEqual(state.stage,stage)
        state.select_stage(0);state.tick(1,True)
        self.assertEqual(state.stage,0)
        self.assertEqual(state.unlocked_stage,2)
        for invalid in (-1,3,True,1.5):self.assertTrue(state.select_stage(invalid))

    def test_old_growth_preserved_and_selected_size_persists(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'pet.json';state=PetState();state.save(path)
            data=json.loads(path.read_text(encoding='utf-8'));del data['unlocked_stage'];data['stage']=2
            path.write_text(json.dumps(data),encoding='utf-8')
            old=PetState.load(path)
            self.assertEqual((old.stage,old.unlocked_stage),(2,2))
            old.select_stage(0);old.save(path);restored=PetState.load(path)
            self.assertEqual((restored.stage,restored.unlocked_stage),(0,2))
            data=json.loads(path.read_text(encoding='utf-8'));data['stage']=2;data['unlocked_stage']=1
            path.write_text(json.dumps(data),encoding='utf-8')
            with self.assertRaises(ValueError):PetState.load(path)

    def test_idle_and_resume_do_not_award_offline_time(self):
        state=PetState();state.tick(10,False)
        self.assertEqual(state.companion_seconds,0)
        state.tick(999999,True)
        self.assertEqual(state.companion_seconds,10)

    def test_roundtrip_and_corrupt_save_not_overwritten(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'pet.json'
            state=PetState();state.outfit='red';state.scene='snow';state.finish('water',100)
            state.save(path);restored=PetState.load(path)
            self.assertEqual(restored.__dict__,state.__dict__)
            path.write_text('{bad',encoding='utf-8')
            with self.assertRaises(ValueError):PetState.load(path)
            self.assertEqual(path.read_text(),'{bad')

    def test_invalid_numbers_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'pet.json';PetState().save(path)
            data=json.loads(path.read_text(encoding='utf-8'));data['values']['bond']=float('nan')
            path.write_text(json.dumps(data),encoding='utf-8')
            with self.assertRaises(ValueError):PetState.load(path)

if __name__=='__main__':unittest.main()
