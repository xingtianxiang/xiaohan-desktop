"""Runtime scene composition with soft alpha and ground contact lighting."""
from functools import lru_cache
from dataclasses import replace
from PIL import Image, ImageDraw, ImageEnhance, ImageFilter, ImageOps
from fetch_game import paint_ball
from animation import fetch_asset

SCENE_SIZE = (420, 290)


class OutdoorRenderer:
    def __init__(self, images):
        self.images = images
        self.backgrounds = {
            name: ImageOps.fit(images['scene_' + name], SCENE_SIZE, Image.Resampling.LANCZOS).convert('RGBA')
            for name in ('park', 'snow')
        }

    def compose_fetch(self,scene,outfit,stage,body_size,sample,walk_name,origin_name):
        size=round(body_size*sample.scale)
        def pose_frame(pose,flip):
            if pose in ('walk','origin_walk','settle'):
                name=origin_name if pose in ('origin_walk','settle') else walk_name
                return self.compose(scene,name,size,sample.x,sample.ground,flip,fetch=replace(sample,carrying=False))
            return self.compose(scene,fetch_asset(outfit,stage,pose),size,sample.x,sample.ground,flip,lift=sample.lift)
        current=pose_frame(sample.pose,sample.flip)
        if sample.mix<1:
            return Image.blend(pose_frame(sample.previous_pose,sample.previous_flip),current,sample.mix)
        return current

    @lru_cache(maxsize=256)
    def sprite(self, scene, name, size, flip):
        image = self.images[name].copy()
        # Generated atlases contain nearly transparent background noise. Remove
        # that floor while retaining intermediate alpha for fur antialiasing.
        alpha = image.getchannel('A').point(lambda a: round(max(0, a - 72) * 255 / 183))
        tint = (244, 235, 200) if scene == 'park' else (204, 222, 243)
        rgb = ImageEnhance.Contrast(image.convert('RGB')).enhance(.96)
        rgb = Image.blend(rgb, Image.new('RGB', rgb.size, tint), .055 if scene == 'park' else .085)
        image = rgb.convert('RGBA'); image.putalpha(alpha)
        image = image.resize((size, size), Image.Resampling.LANCZOS)
        return ImageOps.mirror(image) if flip else image

    def compose(self, scene, name, size, x, ground, flip=False, flame=None, fetch=None,lift=0.):
        background = self.backgrounds[scene]
        frame = background.copy()
        if fetch and not fetch.carrying:
            paint_ball(frame, fetch)
        pet = self.sprite(scene, name, size, flip)
        alpha = pet.getchannel('A')
        box = alpha.point(lambda a: 255 if a >= 32 else 0).getbbox()
        if box is None:
            raise ValueError('出游素材为空：' + name)
        left, top = round(x - size / 2), round(ground - box[3]-lift)
        body_width = box[2] - box[0]
        center = left + (box[0] + box[2]) / 2
        shadow_mask = Image.new('L', SCENE_SIZE)
        draw = ImageDraw.Draw(shadow_mask)
        radius = body_width * .40
        draw.ellipse((center-radius, ground-size*.055, center+radius, ground+size*.04), fill=65)
        shadow_mask = shadow_mask.filter(ImageFilter.GaussianBlur(max(2, size*.025)))
        shadow = Image.new('RGBA', SCENE_SIZE, (45, 64, 37) if scene == 'park' else (65, 91, 126))
        shadow.putalpha(shadow_mask); frame.alpha_composite(shadow)

        # Project only the bottom of the silhouette into a small contact shadow,
        # so planted paws have local weight instead of a detached oval below them.
        feet = alpha.crop((box[0], max(box[1], box[3]-round(size*.12)), box[2], box[3]))
        feet = feet.resize((body_width, max(3, round(size*.025))), Image.Resampling.LANCZOS)
        feet = feet.point(lambda a: round(a*.27/(1+lift))).filter(ImageFilter.GaussianBlur(1))
        contact = Image.new('RGBA', feet.size, (35, 51, 30) if scene == 'park' else (60, 83, 114))
        contact.putalpha(feet)
        frame.alpha_composite(contact, (left+box[0], round(ground-feet.height/2)))
        if flame is not None:
            frame.alpha_composite(flame, (round(x-flame.width/2), round(ground-flame.height)))
        frame.alpha_composite(pet, (left, top))
        if fetch and fetch.carrying:
            paint_ball(frame, fetch)
        return frame.convert('RGB')
