"""Desktop paths and native window conventions."""
from pathlib import Path
import sys

IS_MAC=sys.platform=='darwin'
UI_FONT='PingFang SC' if IS_MAC else 'Microsoft YaHei UI'
TRANSPARENT='systemTransparent' if IS_MAC else '#ff00ff'


def default_data_path():
    if sys.platform=='darwin':
        return Path.home()/'Library/Application Support/XiaohanDesktop/pet.json'
    base=Path(sys.executable).resolve().parent if getattr(sys,'frozen',False) else Path(__file__).resolve().parent
    return base/'data/pet.json'


class MacInstanceLock:
    """Hold the flock descriptor until exit; deleting the lock file would race."""
    def __init__(self,path):
        self.path=Path(path);self.file=None

    def acquire(self):
        import fcntl
        self.path.parent.mkdir(parents=True,exist_ok=True)
        self.file=self.path.open('a')
        try:fcntl.flock(self.file,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:
            self.close();return False
        return True

    def close(self):
        if self.file:
            self.file.close();self.file=None
