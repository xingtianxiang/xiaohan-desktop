import argparse
import ctypes
import json
import math
import os
import sys
from pathlib import Path
import time
import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk, ImageOps
from model import PetState, ACTIONS, STAGES, OUTFITS, NEEDS
from keyboard_activity import KeyboardActivity, user_idle_seconds
from animation import AGES, FETCH_POSES, fetch_asset, motion_frame, required_assets
from outdoor import OutdoorRenderer
from flame import TypingFlame
from more_panel import MorePanel
from fetch_game import fetch_frame, walk_position, ThrowCharge
from throw_controls import draw_throw_controls
from work_break import WorkBreak
from trip_view import TripPicker, draw_scene_controls, draw_scene_notice
from desktop_platform import IS_MAC, UI_FONT, TRANSPARENT, default_data_path, MacInstanceLock

BASE=Path(__file__).resolve().parent
KEY=TRANSPARENT
PAPER='#fffaf2'
INK='#30504c'
TEAL='#368b7d'
TOOLBAR_COLUMNS=3
TOOLBAR_WIDTH=208
TOOLBAR_HEIGHT=214

class DesktopPet:
    def __init__(self,root,data_path,smoke=None):
        self.root,self.data_path,self.smoke=root,Path(data_path),smoke
        self.state=PetState.load(data_path)
        self.images={p.stem:Image.open(p).convert('RGBA') for p in (BASE/'assets').glob('*.png')}
        for name in required_assets(OUTFITS):
            if name not in self.images: raise RuntimeError('缺少素材：'+name)
        self.fetch_anchors=json.loads((BASE/'assets/fetch-anchors.json').read_text(encoding='utf-8'))
        for outfit in OUTFITS:
            for stage in range(3):
                for pose in FETCH_POSES:
                    if fetch_asset(outfit,stage,pose) not in self.fetch_anchors:raise RuntimeError('缺少捡球动作定位数据')
        self.outdoor_renderer=OutdoorRenderer(self.images); self.scene_photo=None
        self.flame=TypingFlame(self.images); self.fire_photo=None; self.more=None; self.last_panel_refresh=0.
        self.work_break=WorkBreak(); self.fetch_power=.55; self.fetch_count=0
        self.fetch_mode=False; self.charge=ThrowCharge()
        self.walk_clock=0.;self.walk_resume=None;self.fetch_origin=walk_position(0.)
        self.keyboard=KeyboardActivity(); self.keyboard.start()
        self.tk_images={}; self.action=None; self.action_started=0.; self.paused=False; self.closing=False
        self.notice='鼠标移到我身上试试'; self.notice_until=time.monotonic()+6
        self.last_tick=time.monotonic(); self.last_save=self.last_tick; self.keyboard_error_shown=False
        self.drag=None; self.toolbar=None; self.chooser=None; self.hide_job=None; self.outdoor=False
        self.buttons={}; self.width,self.height=280,300; self.hit=None
        self.trip_picker=None;self.scene_controls={};self.pressed_control=None
        root.title('小汉 · 桌面宠物'); root.overrideredirect(True); root.attributes('-topmost',True); root.configure(bg=KEY)
        if os.name=='nt': root.wm_attributes('-transparentcolor',KEY)
        elif IS_MAC: root.wm_attributes('-transparent',True)
        root.geometry(f'280x300+{max(0,root.winfo_screenwidth()-330)}+{max(0,root.winfo_screenheight()-380)}')
        self.desktop=tk.Canvas(root,width=280,height=300,bg=KEY,highlightthickness=0); self.desktop.pack()
        self.desktop.bind('<Enter>',lambda e:self.show_toolbar()); self.desktop.bind('<Leave>',lambda e:self.defer_hide())
        self.desktop.bind('<ButtonPress-1>',self.press); self.desktop.bind('<B1-Motion>',self.move)
        self.desktop.bind('<ButtonRelease-1>',self.release); self.desktop.bind('<Button-3>',self.popup)
        if IS_MAC:
            self.desktop.bind('<Button-2>',self.popup)
            self.desktop.bind('<Control-Button-1>',self.popup)
            root.bind('<Command-q>',lambda event:self.close())
            root.createcommand('::tk::mac::Quit',self.close)
        root.bind('<Escape>',self.escape_fetch)
        root.bind('<FocusOut>',lambda e:root.after_idle(self.cancel_unfocused_charge))
        root.protocol('WM_DELETE_WINDOW',self.close); root.after(80,self.tick)

    def photo(self,name,size,flip=False):
        key=(name,size,flip)
        if key not in self.tk_images:
            im=ImageOps.fit(self.images[name],size,Image.Resampling.LANCZOS) if name.startswith('scene_') else self.images[name].resize(size,Image.Resampling.LANCZOS)
            if flip: im=ImageOps.mirror(im)
            # Windows color-key transparency cannot blend partial alpha at sprite edges.
            if os.name=='nt' and not name.startswith('scene_'):im.putalpha(im.getchannel('A').point(lambda value:255 if value>=128 else 0))
            self.tk_images[key]=ImageTk.PhotoImage(im,master=self.root)
        return self.tk_images[key]

    def say(self,text,seconds=4): self.notice,self.notice_until=text,time.monotonic()+seconds

    def save(self):
        try: self.state.save(self.data_path); return True
        except OSError as exc:
            messagebox.showerror('存档失败',str(exc),parent=self.root); return False

    def press(self,e):
        for key,(left,top,right,bottom) in self.scene_controls.items():
            if left<=e.x<=right and top<=e.y<=bottom:
                self.pressed_control=key;self.drag=None;return
        if self.fetch_mode and 37<=e.y<self.height-26:
            self.begin_charge(); return
        self.drag=(e.x_root,e.y_root,self.root.winfo_x(),self.root.winfo_y())

    def move(self,e):
        if self.drag:
            sx,sy,x,y=self.drag
            nx=max(0,min(self.root.winfo_screenwidth()-self.width,x+e.x_root-sx))
            ny=max(0,min(self.root.winfo_screenheight()-self.height,y+e.y_root-sy))
            self.root.geometry(f'+{nx}+{ny}'); self.place_toolbar()

    def release(self,e):
        if self.pressed_control is not None:
            key=self.pressed_control;self.pressed_control=None
            box=self.scene_controls.get(key)
            if box and box[0]<=e.x<=box[2] and box[1]<=e.y<=box[3]:self.outdoor_action(key)
            return
        if self.charge.started is not None:
            power=self.charge.release(time.monotonic())
            self.cancel_charge()
            if self.fetch_mode and 0<=e.x<self.width and 37<=e.y<self.height-26:
                self.throw_ball(power)
            else: self.say('这球先不扔，重新蓄力吧')
            return
        if self.drag and abs(e.x_root-self.drag[0])+abs(e.y_root-self.drag[1])<8: self.show_toolbar()
        self.drag=None

    def floating(self,width,height):
        win=tk.Toplevel(self.root); win.overrideredirect(True); win.attributes('-topmost',True)
        win.configure(bg=PAPER); win.geometry(f'{width}x{height}')
        win.bind('<Enter>',lambda e:self.cancel_hide()); win.bind('<Leave>',lambda e:self.defer_hide())
        return win

    def show_toolbar(self):
        self.cancel_hide()
        if self.more or self.outdoor or self.trip_picker: return
        if self.toolbar and self.toolbar.winfo_exists(): return
        self.toolbar=self.floating(TOOLBAR_WIDTH,TOOLBAR_HEIGHT); self.buttons={}
        actions=[('feed','喂食'),('water','喝水'),('toilet','上厕所'),('pet','摸摸'),('toy','玩具'),('outdoor','出游'),('wardrobe','换装'),('sleep','睡觉'),('more','更多')]
        for i,(key,title) in enumerate(actions):
            tile=tk.Canvas(self.toolbar,width=64,height=66,bg=PAPER,highlightthickness=0,cursor='hand2')
            tile.grid(row=i//TOOLBAR_COLUMNS,column=i%TOOLBAR_COLUMNS,padx=2,pady=2); self.draw_icon(tile,key)
            tile.create_text(32,56,text=title,fill=INK,font=(UI_FONT,9))
            tile.bind('<Enter>',lambda e,t=tile:(self.cancel_hide(),t.configure(bg='#e5f0e8')))
            tile.bind('<Leave>',lambda e,t=tile:(t.configure(bg=PAPER),self.defer_hide()))
            tile.bind('<Button-1>',lambda e,k=key:self.toolbar_action(k,e)); self.buttons[key]=tile
        self.place_toolbar()

    def draw_icon(self,c,key):
        if key=='feed':
            for x,y in [(23,22),(31,19),(39,22)]: c.create_oval(x-4,y-4,x+4,y+4,fill='#d7a064',outline='')
            c.create_polygon(13,25,51,25,46,40,18,40,fill='#85beb4',outline=TEAL,width=2); c.create_line(12,25,52,25,fill=TEAL,width=3)
        elif key=='water':
            c.create_polygon(32,9,18,29,19,37,25,42,39,42,45,37,46,29,fill='#86bed5',outline='#4f8da9',width=2,smooth=True)
            c.create_line(25,29,24,33,28,37,fill='white',width=2,smooth=True)
        elif key=='pet': c.create_polygon(32,40,14,25,15,16,23,12,32,20,41,12,49,16,50,25,fill='#e8a3a1',outline='#c77f7c',width=2,smooth=True)
        elif key=='toy':
            c.create_oval(17,12,47,42,fill='#e7ae6f',outline='#bb8550',width=2)
            c.create_arc(20,11,40,43,start=270,extent=180,style='arc',outline='#fff3d5',width=3)
            c.create_arc(25,11,46,43,start=90,extent=180,style='arc',outline='#fff3d5',width=3)
        elif key=='outdoor':
            c.create_rectangle(29,29,35,43,fill='#bc9467',outline='')
            c.create_polygon(32,8,15,29,24,29,18,36,46,36,40,29,49,29,fill='#89b78b',outline='#638e68',width=2)
        elif key=='wardrobe': c.create_polygon(23,13,16,17,10,27,19,31,22,25,22,42,43,42,43,25,46,31,55,27,49,17,41,13,36,19,28,19,fill='#e9c976',outline='#b49d56',width=2)
        elif key=='sleep':
            c.create_oval(18,10,46,40,fill='#e8ca79',outline=''); c.create_oval(29,6,51,30,fill=PAPER,outline='')
        elif key=='toilet':
            c.create_polygon(17,15,45,15,52,39,12,39,fill='#dcebe2',outline=TEAL,width=2)
            c.create_line(21,20,41,20,46,34,18,34,21,20,fill='#8ebba8',width=2)
            c.create_oval(27,26,37,33,fill=TEAL,outline='')
            for px,py in ((24,23),(30,21),(36,21),(41,24)):c.create_oval(px-2,py-2,px+2,py+2,fill=TEAL,outline='')
        else:
            for x in (19,32,45): c.create_oval(x-3,24,x+3,30,fill=TEAL,outline='')

    def place_toolbar(self):
        if self.more: self.more.place()
        if self.trip_picker:self.trip_picker.place()
        if not self.toolbar: return
        x,y=self.root.winfo_x(),self.root.winfo_y()
        tx=x-TOOLBAR_WIDTH-4 if x>=TOOLBAR_WIDTH+4 else x+self.width+4; ty=y+60
        tx=max(0,min(self.root.winfo_screenwidth()-TOOLBAR_WIDTH,tx)); ty=max(0,min(self.root.winfo_screenheight()-TOOLBAR_HEIGHT,ty))
        self.toolbar.geometry(f'+{tx}+{ty}')
        if self.chooser:
            cy=ty+TOOLBAR_HEIGHT+4
            if cy+160>self.root.winfo_screenheight(): cy=ty-164
            cx=max(0,min(self.root.winfo_screenwidth()-276,tx))
            self.chooser.geometry(f'+{cx}+{max(0,cy)}')

    def cancel_hide(self):
        if self.hide_job: self.root.after_cancel(self.hide_job); self.hide_job=None

    def defer_hide(self): self.cancel_hide(); self.hide_job=self.root.after(450,self.maybe_hide)

    def maybe_hide(self):
        self.hide_job=None; px,py=self.root.winfo_pointerxy()
        if self.more or self.trip_picker: return
        for win in (self.toolbar,self.chooser):
            if win and win.winfo_exists():
                x,y=win.winfo_rootx(),win.winfo_rooty()
                if x<=px<x+win.winfo_width() and y<=py<y+win.winfo_height(): return
        rx,ry=px-self.root.winfo_rootx(),py-self.root.winfo_rooty()
        if self.outdoor and 0<=rx<self.width and 0<=ry<290:return
        if self.hit:
            left,top,size,name,flip=self.hit
            if left<=rx<left+size and top<=ry<top+size:
                im=self.images[name]; ix=min(im.width-1,int((rx-left)*im.width/size)); iy=min(im.height-1,int((ry-top)*im.height/size))
                if flip:ix=im.width-1-ix
                if im.getpixel((ix,iy))[3]>40:return
        self.hide_tools()

    def hide_tools(self):
        self.close_trip_picker()
        self.cancel_hide()
        for win in (self.chooser,self.toolbar):
            if win: win.destroy()
        self.chooser=self.toolbar=None; self.buttons={}

    def toolbar_action(self,key,event=None):
        if key=='wardrobe': self.open_wardrobe()
        elif key=='outdoor': self.scene_menu(event)
        elif key=='more': self.popup(event)
        else: self.start_action(key)

    def open_wardrobe(self):
        if self.chooser: self.chooser.destroy()
        self.chooser=self.floating(276,160)
        for i,(key,title) in enumerate(OUTFITS.items()):
            tile=tk.Canvas(self.chooser,width=90,height=156,bg=PAPER,highlightthickness=0,cursor='hand2'); tile.grid(row=0,column=i)
            tile.create_image(45,100,image=self.photo(key+'_'+AGES[self.state.stage],(90,100)),anchor='s')
            tile.create_text(45,118,text=title,fill=INK,font=(UI_FONT,9))
            tile.create_text(45,140,text='✓ 已穿上' if key==self.state.outfit else '穿这套',fill=TEAL,font=(UI_FONT,9))
            tile.bind('<Button-1>',lambda e,k=key:self.change_outfit(k)); tile.bind('<Enter>',lambda e:self.cancel_hide()); tile.bind('<Leave>',lambda e:self.defer_hide())
        self.place_toolbar()

    def change_outfit(self,key):
        self.state.outfit=key; self.save(); self.say('换上'+OUTFITS[key]+'啦')
        if self.chooser: self.open_wardrobe()

    def scene_menu(self,event=None):
        if self.trip_picker:self.trip_picker.win.lift();return
        self.cancel_charge();self.hide_tools();self.close_more()
        self.trip_picker=TripPicker(self)

    def close_trip_picker(self):
        if self.trip_picker:
            self.trip_picker.win.destroy();self.trip_picker=None

    def outdoor_action(self,key):
        if key=='home':self.set_scene(None)
        elif key=='scene':self.scene_menu()
        elif key=='more':self.popup()
        elif key=='walk':
            if self.action=='walk':self.cancel_action()
            else:self.start_action('walk')
        elif key=='ball':
            self.open_fetch()

    def set_scene(self,scene,walk=True):
        if scene and self.action not in (None,'walk','ball'):
            self.say('等这次互动结束，再一起出门吧');return False
        self.hide_tools();self.scene_controls={};self.pressed_control=None
        self.cancel_charge(); self.fetch_mode=False
        if self.action in ('walk','ball'): self.cancel_action()
        self.walk_clock=0.
        self.outdoor=scene is not None
        if scene: self.state.scene=scene
        self.width,self.height=(420,330) if self.outdoor else (280,300)
        self.resize_window()
        self.place_toolbar(); self.save(); self.say('一起去走走吧' if scene else '回到你身边啦')
        if scene and walk: self.start_action('walk')

    def resize_window(self):
        x=min(self.root.winfo_x(),self.root.winfo_screenwidth()-self.width); y=min(self.root.winfo_y(),self.root.winfo_screenheight()-self.height)
        self.root.geometry(f'{self.width}x{self.height}+{max(0,x)}+{max(0,y)}'); self.desktop.configure(width=self.width,height=self.height)

    def popup(self,event=None):
        self.cancel_charge()
        if self.more:
            self.more.win.lift();return
        self.hide_tools();self.more=MorePanel(self)

    def close_more(self):
        if self.more:
            self.more.win.destroy();self.more=None

    def set_option(self,key,value):
        setattr(self.state,key,value)
        if key=='break_reminders': self.work_break=WorkBreak()
        self.save(); self.say('已开启' if value else '已关闭')

    def select_stage(self,stage):
        if self.action:
            self.say('等这次互动结束，再换个模样吧');return False
        error=self.state.select_stage(stage)
        if error:self.say(error);return False
        self.cancel_charge()
        self.save();self.say('现在是'+STAGES[stage][2]+'小汉啦')
        self.render(time.monotonic())
        if self.more:self.more.refresh()
        return True

    def snooze_break(self):
        self.work_break.snooze(); self.say('好，5 分钟后再叫你')

    def open_fetch(self):
        if self.paused or self.action not in (None,'walk'):
            self.say('先结束当前互动，再来扔球吧'); return False
        self.close_more(); self.hide_tools()
        if not self.outdoor:
            walking_started=self.action_started if self.action=='walk' else None
            self.set_scene('park',walk=False)
            if walking_started is not None:self.action,self.action_started='walk',walking_started
        self.fetch_mode=True; self.width,self.height=420,330
        self.resize_window(); self.say('按住鼠标蓄力，松手把球扔给我吧',6)
        return True

    def begin_charge(self):
        self.drag=None
        if not self.fetch_mode or self.paused or self.action not in (None,'walk'): return False
        error=self.state.check('ball',time.time())
        if error: self.say(error); return False
        if not self.charge.begin(time.monotonic()): return False
        self.desktop.focus_set(); self.desktop.grab_set()
        return True

    def cancel_charge(self):
        self.charge.cancel()
        if self.root.grab_current()==self.desktop: self.desktop.grab_release()

    def cancel_unfocused_charge(self):
        if self.closing: return
        focused=self.root.focus_displayof()
        if focused is None or focused.winfo_toplevel()!=self.root: self.cancel_charge()

    def escape_fetch(self,event=None):
        if self.trip_picker:self.close_trip_picker()
        elif self.charge.started is not None:
            self.cancel_charge(); self.say('已取消蓄力')
        elif self.outdoor: self.set_scene(None)

    def throw_ball(self,power):
        if not self.fetch_mode or self.paused or self.action not in (None,'walk'): return False
        error=self.state.check('ball',time.time())
        if error: self.say(error); return False
        now=time.monotonic()
        self.walk_resume=now-self.action_started if self.action=='walk' else None
        self.fetch_origin=walk_position(self.walk_clock)
        self.fetch_power=min(1.,max(0.,power))
        self.action,self.action_started='ball',now
        self.say(f'看球！力度 {round(self.fetch_power*100)}%')
        return True

    def toggle_pause(self):
        self.cancel_charge()
        if self.action: self.cancel_action()
        self.paused=not self.paused; self.say('已暂停，点“更多”可继续' if self.paused else '继续陪你啦')

    def start_action(self,key):
        if key=='ball': return self.open_fetch()
        if self.paused: self.say('已暂停，请先继续陪伴'); return False
        if self.action: self.say('等这次互动结束再来吧'); return False
        error=self.state.check(key,time.time())
        if error: self.say(error); return False
        if self.fetch_mode: self.set_scene(None)
        self.action,self.action_started=key,time.monotonic(); self.say(ACTIONS[key]['label']+'中…',ACTIONS[key]['duration']+1); return True

    def cancel_action(self):
        self.cancel_charge();self.action=None;self.walk_resume=None;self.say('好啦，继续陪着你')

    def current_fetch(self,now):
        elapsed=now-self.action_started
        anchors={pose:self.fetch_anchors[fetch_asset(self.state.outfit,self.state.stage,pose)] for pose in FETCH_POSES}
        size=round(174*(.70,.88,1.)[self.state.stage])
        sample=fetch_frame(elapsed/ACTIONS['ball']['duration'],self.fetch_power,size,anchors,self.fetch_origin)
        return sample,size

    def pose(self,now):
        outfit,stage=self.state.outfit,self.state.stage
        if self.action:
            if self.action=='toilet':
                elapsed=now-self.action_started
                return (motion_frame(outfit,stage,'walk',elapsed) if elapsed<1.5 or elapsed>6.5 else outfit+'_'+AGES[stage]),False
            if self.action=='ball':
                progress=(now-self.action_started)/ACTIONS['ball']['duration']
                if .44<=progress<.97:return fetch_asset(outfit,stage,self.current_fetch(now)[0].pose),False
                return motion_frame(outfit,stage,'walk',self.walk_clock+max(0,now-self.action_started)*1.4),False
            if self.action=='walk': return motion_frame(outfit,stage,'walk',self.walk_clock if self.outdoor else now-self.action_started),False
            name=ACTIONS[self.action]['pose']
            if name in ('eat','drink','play','sleep'): return motion_frame(outfit,stage,name,now-self.action_started),False
            if name=='shy': return outfit+'_shy',False
        elif self.state.low_needs():
            need=self.state.low_needs()[0]
            return motion_frame(outfit,stage,NEEDS[need][0],0 if self.paused else now),False
        elif self.fetch_mode:
            return motion_frame(outfit,stage,'walk',self.walk_clock),False
        elif not self.paused and self.state.keyboard_enabled and not self.keyboard.error and now-self.keyboard.last_activity<.8:
            return motion_frame(outfit,stage,'type',now),True
        return outfit+'_'+AGES[stage],False

    def render(self,now):
        c=self.desktop; c.delete('all'); name,typing=self.pose(now)
        self.scene_controls={}
        x,y=self.width/2,275; elapsed=now-self.action_started; flip=False
        if self.outdoor and (self.action=='walk' or self.fetch_mode and self.action is None):
            x,y,flip=walk_position(self.walk_clock)
        elif self.action=='walk':
            progress=min(1,elapsed/ACTIONS[self.action]['duration']); x=self.width*.28+self.width*.44*math.sin(progress*math.pi); flip=progress>.5
        base_size=174 if self.outdoor else 240
        size=base_size if name.endswith(('puppy','teen','adult')) else round(base_size*(.70,.88,1.)[self.state.stage])
        fetch=None
        if self.action=='ball':
            fetch,body_size=self.current_fetch(now)
            x,y,flip=fetch.x,fetch.ground,fetch.flip
            size=round(size*fetch.scale)
        self.flame.update(now,typing,self.state.flames and self.state.keyboard_enabled and not self.paused and not self.action and not self.fetch_mode,speed=self.keyboard.speed(now))
        # Keep the fade at the typing body's scale when its pose returns to idle.
        fire_size=round(base_size*(.70,.88,1.)[self.state.stage])
        fire=self.flame.image(now,fire_size,fade_alpha=self.outdoor or IS_MAC)
        if self.outdoor:
            if fetch is None: y=246
            if fetch is not None:
                walk_name=motion_frame(self.state.outfit,self.state.stage,'walk',self.walk_clock+elapsed*1.4)
                origin_name=motion_frame(self.state.outfit,self.state.stage,'walk',self.walk_clock)
                frame=self.outdoor_renderer.compose_fetch(self.state.scene,self.state.outfit,self.state.stage,body_size,fetch,walk_name,origin_name)
            else:frame=self.outdoor_renderer.compose(self.state.scene,name,size,x,y,flip,fire)
            self.scene_photo=ImageTk.PhotoImage(frame,master=self.root)
            c.create_image(0,0,anchor='nw',image=self.scene_photo,tags='outdoor_scene')
            self.hit=None
            if self.fetch_mode:
                charging=self.charge.started is not None
                power=self.charge.power(now) if charging else self.fetch_power if self.action else 0.
                error='陪伴已暂停' if self.paused else self.state.check('ball',time.time())
                draw_throw_controls(c,power,charging,self.action=='ball',error,self.fetch_count)
                c.create_text(402,16,text='×',fill=INK,font=('Segoe UI',18),tags='close_scene'); c.tag_bind('close_scene','<Button-1>',lambda e:self.set_scene(None))
            else:
                self.scene_controls=draw_scene_controls(c,self.state.scene,self.action=='walk')
        else:
            if fire is not None:
                if os.name=='nt':fire.putalpha(fire.getchannel('A').point(lambda value:255 if value>=128 else 0))
                self.fire_photo=ImageTk.PhotoImage(fire,master=self.root)
                c.create_image(x,y,image=self.fire_photo,anchor='s',tags='typing_flame')
            bob=math.sin(now*(1 if self.state.low_needs() else 2))*(.5 if self.state.low_needs() else 1.5) if not self.paused and not self.action else 0
            c.create_image(x,y+bob,image=self.photo(name,(size,size),flip),anchor='s')
            self.hit=(x-size/2,y+bob-size,size,name,flip)
        if self.action=='toilet' and 1.2<elapsed<6.8:
            screen_size=round(base_size*(.70,.88,1.)[self.state.stage])
            self.draw_toilet_screen(c,x,y,screen_size,elapsed)
        if self.action=='pet': c.create_text(x,y-size+35,text='♥',fill='#d58988',font=('Segoe UI',22))
        if self.action=='ball' and elapsed/ACTIONS['ball']['duration']>.92:
            c.create_text(x,y-size-10,text='✦  好棒！  ✦',fill=TEAL,font=(UI_FONT,11,'bold'))
        reminder=self.state.break_reminders and self.work_break.due and not self.paused
        need_text=self.state.need_text() if not self.action else ''
        if now<self.notice_until or self.paused or self.fetch_mode or reminder or need_text:
            text='已暂停' if self.paused else (self.work_break.text() if reminder else fetch.message if self.action=='ball' else self.notice if now<self.notice_until else need_text or '她正等着你的下一球')
            if self.fetch_mode and self.action in (None,'walk') and not reminder and not self.paused:
                text='松手抛出 · 移出场景松手或 Esc 取消' if charging else error or need_text or '按住左键蓄力 · 松手抛出 · Esc 返回'
            if self.outdoor and not self.fetch_mode:draw_scene_notice(c,text)
            else:
                c.create_rectangle(4,self.height-26,self.width-4,self.height-2,fill=PAPER,outline='')
                c.create_text(self.width/2,self.height-14,text=text,width=self.width-16,fill=INK,font=(UI_FONT,9),tags='status_notice')

    def draw_toilet_screen(self,c,x,ground,size,elapsed):
        top=ground-size*.94;left=x-size*.48;panel=size*.32
        for index,color in enumerate(('#b9d1bc','#d9e5ce','#afc9b0')):
            x0=left+index*panel;offset=size*.035 if index%2 else 0
            c.create_polygon(x0,top+offset,x0+panel,top+(0 if offset else size*.035),x0+panel,ground-4,x0,ground-4,
                             fill=color,outline='#6f977e',width=2,tags='toilet_screen')
            for u in (.18,.5,.82):
                c.create_line(x0+panel*u,top+size*.12,x0+panel*u,ground-10,fill='#9cb79d',tags='toilet_screen')
        c.create_text(x,top+size*.47,text='稍等一下'+'.'*(int(elapsed)%3+1),fill=INK,font=(UI_FONT,9),tags='toilet_screen')

    def tick(self):
        if self.closing: return
        now=time.monotonic(); dt=now-self.last_tick; self.last_tick=now
        previous_unlocked=self.state.unlocked_stage
        if not self.paused and self.outdoor and (self.action=='walk' or self.fetch_mode and self.action is None and not self.state.low_needs()):
            self.walk_clock+=min(max(dt,0),.25)
        idle=user_idle_seconds()
        self.work_break.update(now,idle,self.state.break_reminders and not self.paused)
        if not self.paused: self.state.tick(dt,idle is not None and idle<300)
        if self.action and now-self.action_started>=ACTIONS[self.action]['duration']:
            key=self.action; self.action=None; error=self.state.finish(key,time.time())
            self.say(error or ('她收起耳朵了，摸摸她吧' if key=='tap' else ACTIONS[key]['label']+'完成啦'))
            if key=='ball' and not error:
                self.fetch_count+=1
                self.say(f'第 {self.fetch_count} 球带回来了，再来一球吧！',5)
            if key=='ball':
                if self.walk_resume is not None and not self.state.check('walk',time.time()):
                    self.action='walk';self.action_started=now-self.walk_resume
                self.walk_resume=None
            self.save()
        if previous_unlocked!=self.state.unlocked_stage:
            self.say('解锁'+STAGES[self.state.unlocked_stage][2]+'啦！在“更多”里选择模样',10)
            self.save()
        if self.keyboard.error and not self.keyboard_error_shown: self.keyboard_error_shown=True; self.say(self.keyboard.error,15)
        self.render(now)
        if self.more and now-self.last_panel_refresh>.25:
            self.more.refresh();self.last_panel_refresh=now
        if now-self.last_save>30: self.save(); self.last_save=now
        self.root.after(33 if self.flame.level or self.action=='ball' or self.charge.started is not None else 90,self.tick)

    def close(self):
        if not self.save(): return
        self.closing=True; self.cancel_charge(); self.close_more(); self.hide_tools(); self.keyboard.stop(); self.root.destroy()

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--data',default=str(default_data_path()))
    parser.add_argument('--smoke',type=Path)
    parser.add_argument('--verify-package',type=Path,help=argparse.SUPPRESS)
    parser.add_argument('--verify-mac',type=Path,help=argparse.SUPPRESS)
    args=parser.parse_args()
    if os.name=='nt':
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except OSError:
            pass
    root=tk.Tk();root.withdraw()
    mutex=None;mac_lock=None
    if IS_MAC and not args.verify_mac:
        mac_lock=MacInstanceLock(Path(args.data).with_suffix('.lock'))
        try:acquired=mac_lock.acquire()
        except OSError as exc:
            messagebox.showerror('启动失败',f'无法打开存档目录：{exc}');root.destroy();return
        if not acquired:
            messagebox.showinfo('小汉已经在陪你啦','将鼠标移到小汉身上即可看到互动图标。');root.destroy();return
    if os.name=='nt' and not (args.smoke or args.verify_package):
        kernel=ctypes.WinDLL('kernel32',use_last_error=True)
        kernel.CreateMutexW.argtypes=[ctypes.c_void_p,ctypes.c_bool,ctypes.c_wchar_p]
        kernel.CreateMutexW.restype=ctypes.c_void_p
        mutex=kernel.CreateMutexW(None,False,'Local\\XiaohanDesktopCompanion')
        if not mutex:
            messagebox.showerror('启动失败','无法创建单实例锁');root.destroy();return
        if ctypes.get_last_error()==183:
            messagebox.showinfo('小汉已经在陪你啦','将鼠标移到小汉身上即可看到互动图标。');root.destroy();return
    try:
        app=DesktopPet(root,args.data,args.smoke)
    except (OSError,ValueError,KeyError,RuntimeError) as exc:
        if mac_lock:mac_lock.close()
        messagebox.showerror('小汉未能启动',f'{exc}\n\n已有存档不会被覆盖。');root.destroy();return
    root.deiconify()
    if args.verify_mac:
        from mac_check import schedule
        schedule(app,args.verify_mac)
    if args.verify_package:
        from package_check import schedule
        schedule(app,args.verify_package)
    if args.smoke:
        from smoke import schedule
        schedule(app,args.smoke)
    root.mainloop()
    if mac_lock:mac_lock.close()
    if mutex:
        kernel.CloseHandle.argtypes=[ctypes.c_void_p];kernel.CloseHandle(mutex)

if __name__=='__main__':
    main()
