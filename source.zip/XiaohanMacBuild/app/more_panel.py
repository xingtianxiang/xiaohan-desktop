from desktop_platform import UI_FONT
"""Small companion-side controls; no separate client dashboard."""
import tkinter as tk
from model import ACTIONS, STAGES, NEED_LOW, NEED_CRITICAL

PAPER='#fffaf2'
INK='#30504c'
MUTED='#738279'
TEAL='#368b7d'


class MorePanel:
    def __init__(self, app):
        self.app=app
        self.win=tk.Toplevel(app.root)
        self.win.overrideredirect(True);self.win.attributes('-topmost',True)
        self.win.configure(bg=PAPER,highlightbackground='#d7ddd2',highlightthickness=1)
        self.win.bind('<Escape>',lambda e:app.close_more())
        self.win.bind('<FocusIn>',lambda e:app.cancel_hide())
        body=tk.Frame(self.win,bg=PAPER,padx=14,pady=12);body.pack(fill='both',expand=True)
        header=tk.Frame(body,bg=PAPER);header.pack(fill='x')
        tk.Label(header,text='小汉',bg=PAPER,fg=INK,font=(UI_FONT,15,'bold')).pack(side='left')
        self.button(header,'×',app.close_more,width=3).pack(side='right')
        self.subtitle=tk.Label(body,bg=PAPER,fg=MUTED,font=(UI_FONT,9),anchor='w')
        self.subtitle.pack(fill='x',pady=(1,10))
        self.stage_buttons={}
        stages=tk.Frame(body,bg=PAPER);stages.pack(fill='x')
        for stage in range(len(STAGES)):
            button=self.button(stages,'',lambda s=stage:app.select_stage(s),width=8)
            button.grid(row=0,column=stage,sticky='ew',padx=(0,6) if stage<len(STAGES)-1 else 0)
            stages.columnconfigure(stage,weight=1);self.stage_buttons[stage]=button
        progress_header=tk.Frame(body,bg=PAPER);progress_header.pack(fill='x',pady=(8,3))
        self.growth_title=tk.Label(progress_header,bg=PAPER,fg=INK,font=(UI_FONT,8),anchor='w')
        self.growth_title.pack(side='left')
        self.growth_percent=tk.Label(progress_header,bg=PAPER,fg=TEAL,font=(UI_FONT,8),anchor='e')
        self.growth_percent.pack(side='right')
        self.growth_bar=tk.Canvas(body,width=276,height=10,bg=PAPER,highlightthickness=0)
        self.growth_bar.pack(fill='x')
        self.growth_bar.bind('<Configure>',lambda event:self.refresh_growth())
        self.growth=tk.Label(body,bg=PAPER,fg=MUTED,font=(UI_FONT,8),anchor='w',justify='left',wraplength=276,height=2)
        self.growth.pack(fill='x',pady=(4,6))
        self.bars={}
        gauges=tk.Frame(body,bg=PAPER);gauges.pack(fill='x')
        for index,(key,title) in enumerate((('food','饱腹'),('water','水分'),('energy','体力'),('mood','心情'),('toilet','如厕'))):
            cell=tk.Frame(gauges,bg=PAPER);cell.grid(row=index//2,column=index%2,sticky='ew',padx=(0,10) if index%2==0 else 0,pady=(0,8))
            gauges.columnconfigure(index%2,weight=1)
            label=tk.Label(cell,text=title,bg=PAPER,fg=INK,font=(UI_FONT,9),anchor='w');label.pack(fill='x')
            bar=tk.Canvas(cell,width=128,height=6,bg='#e5e9df',highlightthickness=0);bar.pack(fill='x',pady=(4,0))
            self.bars[key]=(label,bar,title)
        self.toilet_button=self.button(gauges,'上厕所',lambda:app.start_action('toilet'))
        self.toilet_button.grid(row=2,column=1,sticky='ew',pady=(0,8))
        tk.Label(body,text='陪她玩',bg=PAPER,fg=INK,font=(UI_FONT,10,'bold'),anchor='w').pack(fill='x',pady=(4,6))
        actions=tk.Frame(body,bg=PAPER);actions.pack(fill='x')
        self.actions={}
        for index,key in enumerate(('snack','ball','walk','tap')):
            button=self.button(actions,ACTIONS[key]['label'],lambda k=key:app.start_action(k))
            button.grid(row=index//2,column=index%2,sticky='ew',padx=(0,8) if index%2==0 else 0,pady=(0,6),ipady=3)
            actions.columnconfigure(index%2,weight=1);self.actions[key]=button
        status=tk.Frame(body,bg=PAPER);status.pack(fill='x',pady=(2,8))
        self.activity=tk.Label(status,bg=PAPER,fg=MUTED,font=(UI_FONT,9),anchor='w');self.activity.pack(side='left')
        self.end=self.button(status,'结束互动',app.cancel_action);self.end.pack(side='right')
        tk.Frame(body,bg='#e3e5da',height=1).pack(fill='x',pady=(0,8))
        self.switches={}
        for key,title in (('keyboard_enabled','跟着打字'),('flames','打字火光'),('break_reminders','休息提醒 · 60 / 10 分钟')):
            row=tk.Frame(body,bg=PAPER);row.pack(fill='x',pady=3)
            tk.Label(row,text=title,bg=PAPER,fg=INK,font=(UI_FONT,10)).pack(side='left')
            button=self.button(row,'',lambda k=key:app.set_option(k,not getattr(app.state,k)),width=8)
            button.pack(side='right');self.switches[key]=button
        tk.Label(body,text='打字越快火越旺，停下后慢慢熄灭',bg=PAPER,fg=MUTED,font=(UI_FONT,8),anchor='w').pack(fill='x',pady=(5,10))
        self.rest_status=tk.Label(body,bg=PAPER,fg=MUTED,font=(UI_FONT,8),anchor='w')
        self.rest_status.pack(fill='x',pady=(0,4))
        self.snooze=self.button(body,'5 分钟后提醒',app.snooze_break)
        self.snooze.pack(fill='x',pady=(0,8))
        footer=tk.Frame(body,bg=PAPER);footer.pack(fill='x')
        self.pause=self.button(footer,'暂停',app.toggle_pause);self.pause.pack(side='left',expand=True,fill='x')
        self.home=self.button(footer,'回到桌面',lambda:app.set_scene(None));self.home.pack(side='left',expand=True,fill='x',padx=6)
        self.button(footer,'退出',app.close,fg='#9c6359').pack(side='left',expand=True,fill='x')
        self.refresh();self.win.update_idletasks()
        self.width=max(304,self.win.winfo_reqwidth());self.height=self.win.winfo_reqheight()
        self.win.geometry(f'{self.width}x{self.height}')
        self.place();self.win.lift();self.win.focus_set()

    def button(self,parent,text,command,**kwargs):
        fg=kwargs.pop('fg',INK)
        return tk.Button(parent,text=text,command=command,bg='#eef2e8',fg=fg,activebackground='#dce9df',activeforeground=INK,
                         relief='flat',borderwidth=0,highlightthickness=1,highlightbackground='#eef2e8',highlightcolor=TEAL,
                         font=(UI_FONT,9),cursor='hand2',padx=7,pady=4,**kwargs)

    def place(self):
        root=self.app.root
        x=root.winfo_x()-self.width-8 if root.winfo_x()>=self.width+8 else root.winfo_x()+self.app.width+8
        y=root.winfo_y()+self.app.height-self.height
        x=max(0,min(root.winfo_screenwidth()-self.width,x));y=max(0,min(root.winfo_screenheight()-self.height,y))
        self.win.geometry(f'+{x}+{y}')

    def refresh(self):
        app=self.app;state=app.state
        self.subtitle.configure(text=f'{STAGES[state.stage][2]} · 亲密 {state.values["bond"]:.0f} · 陪伴 {state.companion_seconds/3600:.1f} 小时')
        busy=app.action is not None
        for stage,button in self.stage_buttons.items():
            locked=stage>state.unlocked_stage
            selected=stage==state.stage
            label=('小','中','大')[stage]+' · '+STAGES[stage][2]
            status=f'{STAGES[stage][0]//3600}小时解锁' if locked else '✓ 使用中' if selected else '选择'
            button.configure(text=label+'\n'+status,state='disabled' if locked or busy else 'normal',
                bg='#dce9df' if selected else '#eef2e8',fg=TEAL if selected else INK)
        self.refresh_growth()
        for key,(label,bar,title) in self.bars.items():
            value=state.need_level(key)
            warning=' · 偏低' if key in state.low_needs() else ''
            if key=='toilet':
                label.configure(text='如厕 · '+('很急' if key in state.urgent_needs() else '想上厕所' if key in state.low_needs() else '舒适'))
            else:label.configure(text=f'{title}  {value:.0f}'+warning)
            bar.delete('all');bar.create_rectangle(0,0,max(0,bar.winfo_width()*value/100),6,fill=TEAL if value>=NEED_LOW else '#b66c58' if value<NEED_CRITICAL else '#c99463',outline='')
        self.toilet_button.configure(state='disabled' if busy or app.paused else 'normal')
        busy=app.action is not None
        for key,button in self.actions.items():
            blocked=busy and not (key=='ball' and app.action=='walk')
            button.configure(state='disabled' if blocked or app.paused else 'normal')
        self.end.configure(state='normal' if busy else 'disabled')
        self.activity.configure(text='陪伴已暂停' if app.paused else (ACTIONS[app.action]['label']+'中' if busy else '需要照顾' if state.low_needs() else '正在陪着你'))
        for key,button in self.switches.items():
            enabled=getattr(state,key);button.configure(text='✓ 已开启' if enabled else '已关闭',fg=TEAL if enabled else MUTED)
        self.pause.configure(text='继续陪伴' if app.paused else '暂停陪伴')
        self.home.configure(state='normal' if app.outdoor else 'disabled')
        self.rest_status.configure(text=app.work_break.text() if state.break_reminders else '休息提醒已关闭')
        self.snooze.configure(state='normal' if state.break_reminders and app.work_break.due and not app.paused else 'disabled')

    def refresh_growth(self):
        state=self.app.state;fraction=state.growth_fraction()
        complete=state.unlocked_stage==len(STAGES)-1
        self.growth_title.configure(text='成长形态全部解锁' if complete else f'下一阶段 · {STAGES[state.unlocked_stage+1][2]}')
        percent=100 if fraction==1 else int(fraction*100)
        self.growth_percent.configure(text='已完成' if complete else f'陪伴进度 {percent}%')
        bar=self.growth_bar;width=max(12,bar.winfo_width())
        bar.delete('all')
        bar.create_line(5,5,width-5,5,width=8,fill='#e5e9df',capstyle='round',tags='track')
        if fraction>0:
            bar.create_line(5,5,5+(width-10)*fraction,5,width=8,fill=TEAL,capstyle='round',tags='progress')
        self.growth.configure(text=state.growth_progress()+ ('\n互动结束后可切换' if self.app.action else ''))
