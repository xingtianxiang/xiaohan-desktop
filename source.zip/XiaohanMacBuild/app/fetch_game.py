"""Ground-plane perspective and a continuous fetch animation."""
from dataclasses import dataclass
import math
from PIL import Image, ImageDraw, ImageFilter

CHARGE_SECONDS = 2.
WALK_CYCLE_SECONDS = 15.


def walk_position(elapsed):
    phase=elapsed/WALK_CYCLE_SECONDS*2*math.pi
    return 210-92*math.cos(phase),246.,math.sin(phase)<0


class ThrowCharge:
    def __init__(self):
        self.started = None

    def begin(self, now):
        if self.started is not None:
            return False
        self.started = now
        return True

    def power(self, now):
        return 0. if self.started is None else min(1., max(0., (now-self.started)/CHARGE_SECONDS))

    def release(self, now):
        if self.started is None:
            return None
        power = self.power(now)
        self.cancel()
        return power

    def cancel(self):
        self.started = None


def throw_point(flight, power):
    t = min(1., max(0., flight))
    power = min(1., max(0., power))
    depth = .18+.82*power
    x = 165+(210+130*power-165)*t
    ground = 260+(254-100*depth-260)*t
    radius = 11*(1-.62*depth*t)
    height = 30+75*power
    return x, ground-radius-4*height*t*(1-t), ground, radius


def ramp(value, start, end):
    t = min(1., max(0., (value-start)/(end-start)))
    return t*t*(3-2*t)


@dataclass(frozen=True)
class FetchFrame:
    x: float
    ground: float
    scale: float
    flip: bool
    ball_x: float
    ball_y: float
    ball_ground: float
    radius: float
    carrying: bool
    message: str
    pose: str
    previous_pose: str
    mix: float
    chase_flip: bool
    return_flip: bool
    origin_flip: bool
    previous_flip: bool
    lift: float
    stride_phase: float


def fetch_frame(progress,power,body_size,anchors,origin=(118.,246.,False)):
    p = min(1., max(0., progress))
    power = min(1., max(0., power))
    depth = .18+.82*power
    ox,oground,oflip=origin
    target_ball,_,target_ground,_=throw_point(1,power)
    chase_flip=target_ball<ox
    returning_flip=ox<target_ball
    direction=-1 if chase_flip else 1
    far_scale=1-.62*depth
    pickup=anchors['pickup']
    radius_base=body_size*pickup['radius']
    far_size=body_size*far_scale
    target_pet=target_ball-direction*far_size*pickup['ball'][0]
    target_body_ground=target_ground+far_size*(pickup['ball'][1]-pickup['radius'])
    outbound=ramp(p,.06,.44)
    inbound=ramp(p,.63,.90)
    scale=1-(1-far_scale)*outbound*(1-inbound)
    size=body_size*scale
    x=ox+(target_pet-ox)*outbound
    ground=oground+(target_body_ground-oground)*outbound
    bx,by,ball_ground,old_radius=throw_point((p-.08)/.22,power)
    radius=radius_base*(old_radius/11)
    by+=old_radius-radius
    if .30 <= p < .42:
        by -= 16*(1-(p-.30)/.12)*abs(math.sin((p-.30)/.12*math.pi*2))
    distance=math.hypot(ox-target_pet,oground-target_body_ground)
    # One four-pose trot cycle covers about half a body length. Integrating
    # perspective scale ties foot cadence to travel, including braking.
    cycles=distance/body_size/.50*(-math.log(far_scale)/(1-far_scale))
    stride_total=max(1,round(cycles))*4+2
    stride_phase=stride_total*math.log((far_scale+(1-far_scale)*inbound)/far_scale)/(-math.log(far_scale))
    step=math.floor(stride_phase)
    pose='walk';previous='origin_walk';mix=ramp(p,0,.08);flip=chase_flip;previous_flip=oflip
    lift=0.
    if p>=.44:
        if p<.50:
            pose,previous,flip,previous_flip='pickup','walk',chase_flip,chase_flip
            mix=ramp(p,.44,.46)
        elif p<.55:
            pose,previous,flip,previous_flip='turnquarter','pickup',chase_flip,chase_flip
            mix=ramp(p,.50,.53)
        elif p<.59:
            pose,previous,flip,previous_flip='turnfront','turnquarter',chase_flip,chase_flip
            mix=ramp(p,.55,.57)
        elif p<.63:
            pose,previous,flip,previous_flip='turnquarter','turnfront',returning_flip,chase_flip
            mix=ramp(p,.59,.61)
        elif p<.90:
            pose='run'+str(step%4)
            previous='turnquarter'
            flip=previous_flip=returning_flip
            mix=ramp(p,.63,.65)
        else:
            # Finish the current stride before lowering the ball, without a
            # sudden change back to the other foot at the arrival boundary.
            pose='drop';previous='run1'
            flip=previous_flip=returning_flip;mix=ramp(p,.90,.94)
            if p>=.97:
                pose,previous,flip,previous_flip='settle','drop',oflip,returning_flip
                mix=ramp(p,.97,1.)
        if p>=.63:
            bend=math.sin(math.pi*inbound)**2
            x=target_pet+(ox-target_pet)*inbound+(-1 if returning_flip else 1)*8*bend
            ground=target_body_ground+(oground-target_body_ground)*inbound+4*bend
            lift=size*.012*math.sin(stride_phase*math.pi/2)**2*ramp(inbound,0,.1)*(1-ramp(inbound,.85,1))

        def ball_at(key,mirrored):
            anchor=anchors['drop' if key=='settle' else key]
            return (x+(-1 if mirrored else 1)*size*anchor['ball'][0],
                    ground-lift-size*anchor['ball'][1],size*anchor['radius'])
        current=ball_at(pose,previous_flip if pose=='settle' else flip)
        old=(target_ball,target_ground-radius,radius) if previous=='walk' else ball_at(previous,previous_flip)
        bx,by,radius=(a+(b-a)*mix for a,b in zip(old,current))
        ball_ground=ground
    carrying=pose not in ('walk','settle')
    message=('看球！我来啦' if p<.44 else '叼起来啦' if p<.55 else '转个身，回来啦' if p<.63 else '给你带回来啦～' if p<.90 else '放这里，再扔一球吧！')
    return FetchFrame(x,ground,scale,flip,bx,by,ball_ground,radius,carrying,message,pose,previous,mix,chase_flip,returning_flip,oflip,previous_flip,lift,stride_phase)


def paint_ball(frame, sample, shadow=True):
    """Render at 3x for a soft edged ball with a grounded, height-aware shadow."""
    layer = Image.new('RGBA', (frame.width*3, frame.height*3))
    draw = ImageDraw.Draw(layer)
    x,y,r = sample.ball_x*3,sample.ball_y*3,sample.radius*3
    if shadow:
        height = max(0, sample.ball_ground-sample.ball_y)
        shade = Image.new('RGBA', layer.size)
        d = ImageDraw.Draw(shade)
        sy = sample.ball_ground*3
        spread = r*(1+height/150)
        d.ellipse((x-spread,sy-r*.28,x+spread,sy+r*.28), fill=(52,65,38,round(70/(1+height/40))))
        layer.alpha_composite(shade.filter(ImageFilter.GaussianBlur(3)))
        draw = ImageDraw.Draw(layer)
    draw.ellipse((x-r,y-r,x+r,y+r),fill='#e6a15b',outline='#a66d40',width=3)
    draw.arc((x-r*.65,y-r,x+r*.4,y+r),70,280,fill='#fff2c4',width=max(2,round(r*.18)))
    draw.ellipse((x-r*.45,y-r*.6,x-r*.05,y-r*.2),fill='#ffe1a1')
    frame.alpha_composite(layer.resize(frame.size,Image.Resampling.LANCZOS))
